# Voting data for PROG2C

The json file includes a list of voting data by county, including county name,
vote numbers and perceptages for Obama and Romney respectively.

Source: [Full US 2012 election county-level
results](http://www.theguardian.com/news/datablog/2012/nov/07/us-2012-election-county-results-download#data)
